
# 🚀 Cloud Function Selenium (Python 3.9 + Headless Chrome)

Este repositório contém uma função HTTP para o **Google Cloud Functions Gen 2**, escrita em **Python 3.9**, que utiliza o **Selenium WebDriver** com **Chrome Headless** para realizar automações web em ambientes serverless.

## 📦 Estrutura

```
cloud-function-selenium/
├── main.py
├── requirements.txt
├── chrome_setup.sh
└── files/
    ├── chromedriver
    └── headless-chromium
```

## 🚀 Deploy

### 1. Clone o repositório

```bash
git clone https://github.com/seu-usuario/cloud-function-selenium.git
cd cloud-function-selenium
```

### 2. Baixe os binários

```bash
bash chrome_setup.sh
```

### 3. Deploy

```bash
gcloud functions deploy selenium-handler \
  --gen2 \
  --runtime=python39 \
  --region=southamerica-east1 \
  --source=. \
  --entry-point=selenium_handler \
  --trigger-http \
  --memory=1Gi \
  --timeout=540s \
  --allow-unauthenticated
```
